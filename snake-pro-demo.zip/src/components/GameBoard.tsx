import React, { useEffect, useState } from 'react';

const GameBoard = () => {
  const [snake, setSnake] = useState([[10, 10]]);
  const [food, setFood] = useState([15, 15]);

  useEffect(() => {
    const interval = setInterval(() => {
      setSnake((prev) => {
        const head = [...prev[0]];
        head[0] += 1;
        const newSnake = [head, ...prev.slice(0, -1)];
        return newSnake;
      });
    }, 200);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative w-[400px] h-[400px] bg-gray-900 grid grid-cols-20 grid-rows-20">
      {snake.map(([x, y], i) => (
        <div key={i} className="bg-green-500 rounded-sm" style={{ gridColumnStart: x, gridRowStart: y }} />
      ))}
      <div className="bg-red-500 rounded-full" style={{ gridColumnStart: food[0], gridRowStart: food[1] }} />
    </div>
  );
};

export default GameBoard;
